<html>
    <head>
        <title>Problem 2</title>
        <style>
        .center {
        margin-top: 10%;
        margin-left: 40%;
        width: 12%;
        border: 3px solid black;
        padding: 10px;
        text-align: center;
        }
        .text {
            text-align: center;
            padding: 10px;
            border-radius: 10px;
        }
        .text2 {
            border-radius: 10px
            border: 1px solid black;
            border-color: pink;
            text-align: center;
            margin-top: 10px;
            background-color: pink;
        }
        </style>
    </head>
    <body>
        <div class="center">
        <form method='POST'>
                <input type="text" name="name" placeholder="Enter Your Name" class="text">
                <input type="submit" name = "submit" value="Submit" class="text2">
        </form>
                <?php 
                $name = $_POST['name'];
                echo "Your Name Is <br>
                       <h3>$name<h3> ";
                
                ?>
        </div>
       
    </body>
</html>