<!DOCTYPE html>
<head>
    <title>Problem 1</title>
    <style>
        .center {
        margin-top: 10%;
        margin-left: 40%;
        width: 12%;
        border: 3px solid black;
        padding: 10px;
        text-align: center;
        }
</style>
</head>

    <body>
    <div class="center">
        <?php 
        $E1 = 25000;
        $formatted1 = number_format($E1, 2);
        $E2 = 30350;
        $formatted2 = number_format($E2, 2);
        $E3 = 40250;
        $formatted3 = number_format($E3, 2);
        $E4 = 20125;
        $formatted4 = number_format($E4, 2);
        $E5 = 35358;
        $formatted5 = number_format($E5, 2);
        $Total = 151083;
        $formatted6 = number_format($Total, 3);
 
        echo "<table border = 1 >
        
        <tr><td>Salary of Employee 1</td><td>$formatted1 php</td></tr>
        <tr><td>Salary of Employee 2</td><td>$formatted2 php</td></tr>
        <tr><td>Salary of Employee 3</td><td>$formatted3 php</td></tr>
        <tr><td>Salary of Employee 4</td><td>$formatted4 php</td></tr>
        <tr><td>Salary of Employee 5</td><td>$formatted5 php</td></tr>
        <tr><td>TOTAL: </td><td>$formatted6 php</td>l</tr>
        </table>";
        ?>
    </div>

    </body>

</html>