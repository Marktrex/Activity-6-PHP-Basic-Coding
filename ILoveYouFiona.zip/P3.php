<html>
    <head>
        <title>Problem 3</title>
        <style>
        .center {
        margin-top: 10%;
        margin-left: 40%;
        width: 12%;
        border: 3px solid black;
        padding: 10px;
        text-align: center;
        }
        
        .text1 {
            border-radius: 10px
            border: 1px solid black;
            border-color: pink;
            text-align: center;
            margin-top: 10px;
            background-color: pink;
        }
        .text2 {
            border-radius: 10px
            border: 1px solid black;
            border-color: cyan;
            text-align: center;
            margin-top: 10px;
            background-color: cyan;
        }
        </style>
    </head>
    <body>
    <?php
            $text = 'TANGINA MO JEPOY DIZON';
            $text1 = preg_replace('/(\b[a-z])/i','<span style="color:red;">\1</span>',$text);
         
            ?>
        <div class="center">
         <p class="text1">Sample String <br><br> <?php echo $text ?></p>
         <p class="text2"> Output <br><br> <?php echo $text1 ?></p>
        </div>
       
    </body>
</html>